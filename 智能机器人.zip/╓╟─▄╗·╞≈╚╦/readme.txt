﻿数据库配置 : 
database : user1
table : user
id  name usename password